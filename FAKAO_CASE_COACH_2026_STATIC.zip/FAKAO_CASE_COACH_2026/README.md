# 2026 法考主觀題 Case Coach（純前端版）

## 內容
- 案例：139 個
- 設問：821 條
- 科目：刑法、刑事訴訟法、行政法與行政訴訟法、民法、商法、民事訴訟法與仲裁制度
- 模式：Learn / Drill / Exam / Review
- 不使用 API、AI、登入、資料庫或後端。
- 學習進度保存在瀏覽器 `localStorage`。

## 最簡單使用方法
直接雙擊 `index.html` 即可。網站資料以 `data.js` 載入，所以不依賴 `fetch()`，一般情況下用 `file://` 亦可運作。

若瀏覽器對本機 localStorage 有限制，可在資料夾內開一個最簡單的靜態伺服器：

```bash
python -m http.server 8080
```

然後瀏覽 `http://localhost:8080/`。

## 上載到 law.edu.hk
將資料夾內以下檔案／資料夾原樣上載到例如：

`public_html/casecoach2026/`

必要檔案：
- `index.html`
- `styles.css`
- `app.js`
- `data.js`

`sources/`、`manifest.json`、`README.md` 主要供審核追溯，可一併保留。

網站不需要 PHP、Node、MySQL、API key 或任何 server runtime。

## 學習設計
### Learn
逐題：初步結論 → 圈關鍵事實 → 定位 Issue → 結論/規則/涵攝 → 官方答案 → 自評。

### Drill
減少提示，只顯示設問；需要時自行展開案情；交答案後才顯示官方答案。

### Exam
完整案例一次顯示；所有設問回答完再交卷；交卷前不顯示解析。

### Review
依自評安排：
- 不懂：1 日後
- 模糊：3 日後
- 掌握：初次 7 日後；之後逐步拉長，最高約 30 日

## 批改限制（刻意設計）
本版沒有 AI，因此不聲稱可以可靠批改任意自然語言答案。網站採：
1. 學生先作答；
2. 顯示教材官方答案；
3. 將官方答案 deterministic 地切成閱讀 checklist；
4. 學生自己標記「不懂／模糊／掌握」。

只有官方答案開頭可可靠辨識為「可以/不可以」「合法/不合法」「成立/不成立」等時，Learn 才會顯示快速結論按鈕；該按鈕亦不代表全文批改。

## Source of truth
教材內容全部來自使用者提供的兩份 source-faithful Markdown。網站沒有用外部法律知識去自行修正、補寫或取代教材內容。

- 上冊 SHA-256：4399091b394211485abdca90cb5a84d5fd4f8477358c41ac9f4662e74cfa128c
- 下冊 SHA-256：d192424b84a48973e4675f36a2cdb3c169a755c21a9ccfa3ada7b7b799533bec

少數原始 Markdown 本身的案例標題層級不一致；網站 parser 只為導航做結構化。上冊兩個缺失於正文的案例標題，由該書目錄補回，UI 會標示「標題由目錄補回」。
