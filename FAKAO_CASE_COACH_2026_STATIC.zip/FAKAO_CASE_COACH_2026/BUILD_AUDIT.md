# Build Audit

- Cases: 139
- Questions: 821
- Subject distribution: {"刑法": {"cases": 32, "questions": 131}, "刑事訴訟法": {"cases": 24, "questions": 141}, "行政法與行政訴訟法": {"cases": 24, "questions": 127}, "民法": {"cases": 22, "questions": 215}, "商法": {"cases": 18, "questions": 120}, "民事訴訟法與仲裁制度": {"cases": 19, "questions": 87}}
- Type distribution: {"答題範例": 18, "案例指導": 71, "練習題": 6, "進階案例": 44}
- Question answer fields blank after fallback: 0
- Questions intentionally using full official answer-section fallback: 76
- Cases with conservative full-section fallback: 12
- API calls required at runtime: 0
- External JavaScript/CSS dependencies: 0
- Backend required: No
